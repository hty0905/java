package ifexample;

public class IfExample1 {

	public static void main(String[] args) {

		int age =10;
		
		if(age>=8) { 
			System.out.println("학교에 다닙니다");
		}
		else {
			System.out.println("학교에 안다녀");
		}
	}

}
