package chapter2;

public class Constant {

	public static void main(String[] args) {
		final int MAX_NUM = 100;
		final double PI=3.14;
		
		final int STUDENT_NUM = 30;
		int num=30;
		if (num==STUDENT_NUM ) {System.out.println(STUDENT_NUM);}
		
		
	}

}
