package chapter2;

public class CharacterEx {

	public static void main(String[] args) {

		char ch = 'A';
		
		System.out.println(ch);
		System.out.println((int)ch);
		
		ch=66;
		
		System.out.println(ch);
		System.out.println((int)ch);
		
		int ch2=67;
		System.out.println(ch2);
		System.out.println((char)ch2);
		
	}

}
