package chapter2;

public class VariableRx {

	public static void main(String[] args) {
		
		int num;
		num = 10;
		
		System.out.println(num);
		
		int level=20;
		System.out.println(level);
		
		int ns;
		int numberOfStudent;
		
	}

}
