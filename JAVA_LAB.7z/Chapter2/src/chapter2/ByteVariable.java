package chapter2;

public class ByteVariable {

	public static void main(String[] args) {
		byte bData = -128;
		System.out.println(bData);
		
		byte bData2 = 127;
		System.out.println(bData2);
	}

}
