package chapter2;

public class DoubleEx {

	int abc;
	
	//var abd;
	
	public static void main(String[] args) {

		double dNum = 3.14;
		float fNum = 3.14f;
		
		System.out.println(dNum);
		System.out.println(fNum);
		
		var sex=66;
		sex='a';
		System.out.println(sex);
		System.out.println((char)sex);
	}

}
