package chapter2;

public class VariableEx2 {

	public static void main(String[] args) {

		int num = 1234567890;
		long num1 = 12345678900L;
		float num2 = 1234.567890f;
		int level = 50;
		System.out.println(num);
		System.out.println(num1);
		System.out.println(num2);
		
		
	}

}
