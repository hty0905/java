package reference;

public class Circle {

	Point point;
	int radius;
	
	public Circle() {
		point = new Point();
	}
}
