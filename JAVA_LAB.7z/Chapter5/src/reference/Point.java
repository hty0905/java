package reference;

public class Point {
	int x;
	int y;
}
