package assignment;

public class OperationEx {

	public static void main(String[] args) {
		
		int age = 24;
		System.out.println(age);
		
		int num=10;
		int num2=-num;
		System.out.println(num);
		System.out.println(num2);
		System.out.println(5/3);
		System.out.println(5%3);
	}

}
